#!/bin/sh
# Re-runs this verification (sva-verify must be on PATH).
cd "$(dirname "$0")/../../../benchmarks/symbiyosys-examples/tests/junit/junit_assert_fail" && sva-verify --timeout=20 --top=top -DFORMAL -DFAIL test.sv
