#!/bin/sh
# Re-runs this verification (sva-verify must be on PATH).
cd "$(dirname "$0")/../../../benchmarks/symbiyosys-examples/tests/unsorted/multi_assert_btormc" && sva-verify --timeout=20 --top=test -DFORMAL multi_assert.v
