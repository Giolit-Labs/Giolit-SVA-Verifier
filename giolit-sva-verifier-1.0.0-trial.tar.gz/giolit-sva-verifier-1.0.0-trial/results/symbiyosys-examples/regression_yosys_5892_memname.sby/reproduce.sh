#!/bin/sh
# Re-runs this verification (sva-verify must be on PATH).
cd "$(dirname "$0")/../../../benchmarks/symbiyosys-examples/tests/regression/yosys_5892_memname" && sva-verify --timeout=20 --top=top -DFORMAL top.sv
