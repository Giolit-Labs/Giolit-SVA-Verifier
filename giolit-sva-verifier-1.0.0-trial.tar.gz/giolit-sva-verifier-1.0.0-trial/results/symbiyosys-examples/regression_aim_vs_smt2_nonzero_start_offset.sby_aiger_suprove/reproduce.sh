#!/bin/sh
# Re-runs this verification (sva-verify must be on PATH).
cd "$(dirname "$0")/../../../benchmarks/symbiyosys-examples/tests/regression/aim_vs_smt2_nonzero_start_offset_aiger_suprove" && sva-verify --timeout=20 --top=test -DFORMAL test.sv
