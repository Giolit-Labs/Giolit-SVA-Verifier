#!/bin/sh
# Re-runs this verification (sva-verify must be on PATH).
cd "$(dirname "$0")/../../../benchmarks/symbiyosys-examples/tests/unsorted/2props1trace" && sva-verify --timeout=20 --top=top -DFORMAL top.sv
