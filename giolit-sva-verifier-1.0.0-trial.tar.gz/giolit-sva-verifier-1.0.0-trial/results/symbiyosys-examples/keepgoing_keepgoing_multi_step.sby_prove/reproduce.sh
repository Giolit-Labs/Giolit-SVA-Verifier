#!/bin/sh
# Re-runs this verification (sva-verify must be on PATH).
cd "$(dirname "$0")/../../../benchmarks/symbiyosys-examples/tests/keepgoing/keepgoing_multi_step_prove" && sva-verify --timeout=20 --top=test -DFORMAL keepgoing_multi_step.sv
