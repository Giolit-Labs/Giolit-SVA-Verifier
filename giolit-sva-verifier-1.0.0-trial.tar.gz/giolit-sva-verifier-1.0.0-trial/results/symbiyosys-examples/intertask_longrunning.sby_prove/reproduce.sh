#!/bin/sh
# Re-runs this verification (sva-verify must be on PATH).
cd "$(dirname "$0")/../../../benchmarks/symbiyosys-examples/tests/intertask/longrunning_prove" && sva-verify --timeout=20 --top=top -DFORMAL autotune_div.sv
