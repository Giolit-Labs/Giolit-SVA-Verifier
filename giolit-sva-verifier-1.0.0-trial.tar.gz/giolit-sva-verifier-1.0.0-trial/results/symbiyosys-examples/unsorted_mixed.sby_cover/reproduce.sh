#!/bin/sh
# Re-runs this verification (sva-verify must be on PATH).
cd "$(dirname "$0")/../../../benchmarks/symbiyosys-examples/tests/unsorted/mixed_cover" && sva-verify --timeout=20 --top=test -DFORMAL mixed.v
