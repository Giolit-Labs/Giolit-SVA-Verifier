#!/bin/sh
# Re-runs this verification (sva-verify must be on PATH).
cd "$(dirname "$0")/../../../benchmarks/symbiyosys-examples/tests/unsorted/both_ex_cover" && sva-verify --timeout=20 --top=test -DFORMAL both_ex.v
