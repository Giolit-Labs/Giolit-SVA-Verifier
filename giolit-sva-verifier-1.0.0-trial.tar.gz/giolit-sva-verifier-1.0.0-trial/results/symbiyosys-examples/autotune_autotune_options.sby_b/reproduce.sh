#!/bin/sh
# Re-runs this verification (sva-verify must be on PATH).
cd "$(dirname "$0")/../../../benchmarks/symbiyosys-examples/tests/autotune/autotune_options_b" && sva-verify --timeout=20 --top=top -DFORMAL autotune_div.sv
