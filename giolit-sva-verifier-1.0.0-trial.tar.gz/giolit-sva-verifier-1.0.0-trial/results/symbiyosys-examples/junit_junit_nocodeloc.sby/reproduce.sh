#!/bin/sh
# Re-runs this verification (sva-verify must be on PATH).
cd "$(dirname "$0")/../../../benchmarks/symbiyosys-examples/tests/junit/junit_nocodeloc" && sva-verify --timeout=20 --top=test -DFORMAL multi_assert.v
