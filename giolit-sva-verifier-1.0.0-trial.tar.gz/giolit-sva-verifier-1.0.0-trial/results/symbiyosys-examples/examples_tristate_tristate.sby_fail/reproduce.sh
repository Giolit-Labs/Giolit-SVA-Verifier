#!/bin/sh
# Re-runs this verification (sva-verify must be on PATH).
cd "$(dirname "$0")/../../../benchmarks/symbiyosys-examples/docs/examples/tristate/tristate_fail" && sva-verify --timeout=20 --top=top_fail -DFORMAL tristates.v
