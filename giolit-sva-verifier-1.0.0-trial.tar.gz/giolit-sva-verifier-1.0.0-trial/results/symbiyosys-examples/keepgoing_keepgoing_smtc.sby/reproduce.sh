#!/bin/sh
# Re-runs this verification (sva-verify must be on PATH).
cd "$(dirname "$0")/../../../benchmarks/symbiyosys-examples/tests/keepgoing/keepgoing_smtc" && sva-verify --timeout=20 --top=test -DFORMAL keepgoing_same_step.sv
