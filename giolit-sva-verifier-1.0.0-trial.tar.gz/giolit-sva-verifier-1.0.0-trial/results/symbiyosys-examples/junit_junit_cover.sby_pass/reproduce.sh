#!/bin/sh
# Re-runs this verification (sva-verify must be on PATH).
cd "$(dirname "$0")/../../../benchmarks/symbiyosys-examples/tests/junit/junit_cover_pass" && sva-verify --timeout=20 --top=top -DFORMAL test.sv
