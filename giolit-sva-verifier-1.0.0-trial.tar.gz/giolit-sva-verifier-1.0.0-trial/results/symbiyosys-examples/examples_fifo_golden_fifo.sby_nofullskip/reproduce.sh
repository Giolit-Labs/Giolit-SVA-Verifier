#!/bin/sh
# Re-runs this verification (sva-verify must be on PATH).
cd "$(dirname "$0")/../../../benchmarks/symbiyosys-examples/docs/examples/fifo/golden/fifo_nofullskip" && sva-verify --timeout=20 --top=fifo -DFORMAL -DNO_FULL_SKIP=1 fifo.sv
