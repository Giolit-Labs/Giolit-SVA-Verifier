#!/bin/sh
# Re-runs this verification (sva-verify must be on PATH).
cd "$(dirname "$0")/../../../benchmarks/symbiyosys-examples/tests/unsorted/redxor" && sva-verify --timeout=20 --top=test -DFORMAL redxor.v
