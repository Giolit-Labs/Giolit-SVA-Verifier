#!/bin/sh
# Re-runs this verification (sva-verify must be on PATH).
cd "$(dirname "$0")/../../../benchmarks/symbiyosys-examples/tests/statusdb/reset" && sva-verify --timeout=20 --top=demo -DFORMAL reset.sv
