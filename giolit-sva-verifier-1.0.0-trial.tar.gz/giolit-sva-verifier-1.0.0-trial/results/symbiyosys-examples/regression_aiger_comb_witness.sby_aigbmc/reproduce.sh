#!/bin/sh
# Re-runs this verification (sva-verify must be on PATH).
cd "$(dirname "$0")/../../../benchmarks/symbiyosys-examples/tests/regression/aiger_comb_witness_aigbmc" && sva-verify --timeout=20 --top=top -DFORMAL top.sv
