#!/bin/sh
# Re-runs this verification (sva-verify must be on PATH).
cd "$(dirname "$0")/../../../benchmarks/symbiyosys-examples/docs/examples/indinv/prove_p23_p1" && sva-verify --timeout=20 --top=example -DFORMAL -DASSERT_PX=p1 example.sv
