#!/bin/sh
# Re-runs this verification (sva-verify must be on PATH).
cd "$(dirname "$0")/../../../benchmarks/symbiyosys-examples/tests/regression/unroll_noincr_traces_boolector" && sva-verify --timeout=20 --top=top -DFORMAL top.sv
