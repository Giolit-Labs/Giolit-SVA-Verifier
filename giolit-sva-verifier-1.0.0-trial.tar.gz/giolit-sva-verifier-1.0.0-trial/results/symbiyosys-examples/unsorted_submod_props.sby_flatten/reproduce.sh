#!/bin/sh
# Re-runs this verification (sva-verify must be on PATH).
cd "$(dirname "$0")/../../../benchmarks/symbiyosys-examples/tests/unsorted/submod_props_flatten" && sva-verify --timeout=20 --top=top -DFORMAL test.sv
