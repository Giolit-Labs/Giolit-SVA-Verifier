#!/bin/sh
# Re-runs this verification (sva-verify must be on PATH).
cd "$(dirname "$0")/../../../benchmarks/symbiyosys-examples/tests/unsorted/bmc_len_smtbmc_fail" && sva-verify --timeout=20 --top=top -DFORMAL top.sv
