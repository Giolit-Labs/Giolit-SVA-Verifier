#!/bin/sh
# Re-runs this verification (sva-verify must be on PATH).
cd "$(dirname "$0")/../../../benchmarks/ebmc-regression/ebmc/ranking-function" && sva-verify --timeout=20 --property main.p_hour clock24h.sv
