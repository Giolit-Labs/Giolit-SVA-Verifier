#!/bin/sh
# Re-runs this verification (sva-verify must be on PATH).
cd "$(dirname "$0")/../../../benchmarks/ebmc-regression/ebmc/ranking-function" && sva-verify --timeout=20 lexicographic_ranking_function1.sv
