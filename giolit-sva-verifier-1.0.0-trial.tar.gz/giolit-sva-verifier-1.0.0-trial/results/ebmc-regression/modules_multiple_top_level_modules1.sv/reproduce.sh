#!/bin/sh
# Re-runs this verification (sva-verify must be on PATH).
cd "$(dirname "$0")/../../../benchmarks/ebmc-regression/verilog/modules" && sva-verify --timeout=20 multiple_top_level_modules1.sv
