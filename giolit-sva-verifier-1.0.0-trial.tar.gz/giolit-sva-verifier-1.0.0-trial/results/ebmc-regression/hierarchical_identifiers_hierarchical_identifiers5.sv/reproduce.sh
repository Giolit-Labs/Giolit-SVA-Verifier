#!/bin/sh
# Re-runs this verification (sva-verify must be on PATH).
cd "$(dirname "$0")/../../../benchmarks/ebmc-regression/verilog/hierarchical_identifiers" && sva-verify --timeout=20 hierarchical_identifiers5.sv
