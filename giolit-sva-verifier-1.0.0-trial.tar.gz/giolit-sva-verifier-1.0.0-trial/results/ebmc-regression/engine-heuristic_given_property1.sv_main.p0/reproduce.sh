#!/bin/sh
# Re-runs this verification (sva-verify must be on PATH).
cd "$(dirname "$0")/../../../benchmarks/ebmc-regression/ebmc/engine-heuristic" && sva-verify --timeout=20 --property main.p0 given_property1.sv
