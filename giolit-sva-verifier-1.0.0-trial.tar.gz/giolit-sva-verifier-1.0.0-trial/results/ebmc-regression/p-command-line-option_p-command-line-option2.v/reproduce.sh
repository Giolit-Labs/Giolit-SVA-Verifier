#!/bin/sh
# Re-runs this verification (sva-verify must be on PATH).
cd "$(dirname "$0")/../../../benchmarks/ebmc-regression/ebmc/p-command-line-option" && sva-verify --timeout=20 -p 0 p-command-line-option2.v
