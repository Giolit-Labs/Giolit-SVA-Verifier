#!/bin/sh
# Re-runs this verification (sva-verify must be on PATH).
cd "$(dirname "$0")/../../../benchmarks/ebmc-regression/verilog/primitive_gates" && sva-verify --timeout=20 --top=main xnor1.sv
