#!/bin/sh
# Re-runs this verification (sva-verify must be on PATH).
cd "$(dirname "$0")/../../../benchmarks/ebmc-regression/ebmc/liveness-lemma-engine" && sva-verify --timeout=20 delay10-fail.sv
