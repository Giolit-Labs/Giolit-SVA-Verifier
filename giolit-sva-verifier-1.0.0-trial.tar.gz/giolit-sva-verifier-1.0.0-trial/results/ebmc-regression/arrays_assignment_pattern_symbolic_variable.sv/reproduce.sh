#!/bin/sh
# Re-runs this verification (sva-verify must be on PATH).
cd "$(dirname "$0")/../../../benchmarks/ebmc-regression/verilog/arrays" && sva-verify --timeout=20 assignment_pattern_symbolic_variable.sv
