#!/bin/sh
# Re-runs this verification (sva-verify must be on PATH).
cd "$(dirname "$0")/../../../benchmarks/ebmc-regression/verilog/interface" && sva-verify --timeout=20 --top=main port_array3.sv
