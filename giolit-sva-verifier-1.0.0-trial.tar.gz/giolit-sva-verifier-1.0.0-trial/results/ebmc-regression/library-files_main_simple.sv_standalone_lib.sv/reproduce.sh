#!/bin/sh
# Re-runs this verification (sva-verify must be on PATH).
cd "$(dirname "$0")/../../../benchmarks/ebmc-regression/ebmc/library-files" && sva-verify --timeout=20 main_simple.sv standalone_lib.sv
