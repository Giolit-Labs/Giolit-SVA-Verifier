#!/bin/sh
# Re-runs this verification (sva-verify must be on PATH).
cd "$(dirname "$0")/../../../benchmarks/ebmc-regression/ebmc/Include1" && sva-verify --timeout=20 --top=main -Isubdir main.v
