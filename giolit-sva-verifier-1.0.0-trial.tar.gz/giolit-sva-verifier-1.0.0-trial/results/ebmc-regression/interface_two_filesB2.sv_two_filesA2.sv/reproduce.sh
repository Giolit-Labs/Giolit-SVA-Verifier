#!/bin/sh
# Re-runs this verification (sva-verify must be on PATH).
cd "$(dirname "$0")/../../../benchmarks/ebmc-regression/verilog/interface" && sva-verify --timeout=20 two_filesB2.sv two_filesA2.sv
