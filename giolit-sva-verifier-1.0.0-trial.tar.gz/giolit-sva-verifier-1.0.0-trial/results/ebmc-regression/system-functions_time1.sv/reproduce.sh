#!/bin/sh
# Re-runs this verification (sva-verify must be on PATH).
cd "$(dirname "$0")/../../../benchmarks/ebmc-regression/verilog/system-functions" && sva-verify --timeout=20 time1.sv
