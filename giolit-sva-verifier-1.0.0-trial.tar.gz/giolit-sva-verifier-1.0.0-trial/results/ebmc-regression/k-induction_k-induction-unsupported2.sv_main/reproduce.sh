#!/bin/sh
# Re-runs this verification (sva-verify must be on PATH).
cd "$(dirname "$0")/../../../benchmarks/ebmc-regression/ebmc/k-induction" && sva-verify --timeout=20 --top=main k-induction-unsupported2.sv
