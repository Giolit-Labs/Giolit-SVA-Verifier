#!/bin/sh
# Re-runs this verification (sva-verify must be on PATH).
cd "$(dirname "$0")/../../../benchmarks/ebmc-regression/ebmc/ic3" && sva-verify --timeout=20 --property main.p0 non_inductive1.sv
