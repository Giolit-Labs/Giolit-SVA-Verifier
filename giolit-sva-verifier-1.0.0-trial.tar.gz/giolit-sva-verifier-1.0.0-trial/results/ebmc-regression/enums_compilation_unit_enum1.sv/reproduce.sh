#!/bin/sh
# Re-runs this verification (sva-verify must be on PATH).
cd "$(dirname "$0")/../../../benchmarks/ebmc-regression/verilog/enums" && sva-verify --timeout=20 compilation_unit_enum1.sv
