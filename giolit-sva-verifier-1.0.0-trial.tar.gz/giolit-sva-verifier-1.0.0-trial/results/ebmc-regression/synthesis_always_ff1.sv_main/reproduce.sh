#!/bin/sh
# Re-runs this verification (sva-verify must be on PATH).
cd "$(dirname "$0")/../../../benchmarks/ebmc-regression/verilog/synthesis" && sva-verify --timeout=20 --top=main always_ff1.sv
