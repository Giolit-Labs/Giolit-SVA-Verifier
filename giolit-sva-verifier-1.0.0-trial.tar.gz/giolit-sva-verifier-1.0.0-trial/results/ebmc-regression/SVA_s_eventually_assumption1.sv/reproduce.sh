#!/bin/sh
# Re-runs this verification (sva-verify must be on PATH).
cd "$(dirname "$0")/../../../benchmarks/ebmc-regression/verilog/SVA" && sva-verify --timeout=20 s_eventually_assumption1.sv
