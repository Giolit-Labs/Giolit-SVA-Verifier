#!/bin/sh
# Re-runs this verification (sva-verify must be on PATH).
cd "$(dirname "$0")/../../../benchmarks/ebmc-regression/ebmc/CLI" && sva-verify --timeout=20 very_long_property1.sv
