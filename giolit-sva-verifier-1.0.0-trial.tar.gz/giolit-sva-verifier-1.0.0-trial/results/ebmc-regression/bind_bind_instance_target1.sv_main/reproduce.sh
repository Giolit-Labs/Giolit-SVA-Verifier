#!/bin/sh
# Re-runs this verification (sva-verify must be on PATH).
cd "$(dirname "$0")/../../../benchmarks/ebmc-regression/verilog/bind" && sva-verify --timeout=20 --top=main bind_instance_target1.sv
