#!/bin/sh
# Re-runs this verification (sva-verify must be on PATH).
cd "$(dirname "$0")/../../../benchmarks/ebmc-regression/ebmc/ranking-function" && sva-verify --timeout=20 counter_in_module1.sv
