#!/bin/sh
# Re-runs this verification (sva-verify must be on PATH).
cd "$(dirname "$0")/../../../benchmarks/ebmc-regression/ebmc/new-ic3" && sva-verify --timeout=20 --property main.p0 proved1.sv
