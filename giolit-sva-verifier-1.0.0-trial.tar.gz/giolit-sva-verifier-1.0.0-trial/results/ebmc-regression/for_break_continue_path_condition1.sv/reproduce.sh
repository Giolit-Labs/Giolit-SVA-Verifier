#!/bin/sh
# Re-runs this verification (sva-verify must be on PATH).
cd "$(dirname "$0")/../../../benchmarks/ebmc-regression/verilog/for" && sva-verify --timeout=20 break_continue_path_condition1.sv
