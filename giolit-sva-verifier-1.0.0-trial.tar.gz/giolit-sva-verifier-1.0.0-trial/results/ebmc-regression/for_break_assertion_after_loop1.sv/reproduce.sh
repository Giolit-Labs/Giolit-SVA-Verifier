#!/bin/sh
# Re-runs this verification (sva-verify must be on PATH).
cd "$(dirname "$0")/../../../benchmarks/ebmc-regression/verilog/for" && sva-verify --timeout=20 break_assertion_after_loop1.sv
