module top(input clk);
    reg [7:0] counter = 0;

    always @(posedge clk) begin
        counter <= counter + 1;
        assert (counter < 4);
    end
endmodule
