module \\(foo) (input a);
    always @* begin
        assert_foo: assert (a);
    end
    \\(bar) \\(bar)=i= (.a(a));
endmodule

