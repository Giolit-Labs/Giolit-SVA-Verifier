module \\(bar) (input a);
    always @* begin
        assert_bar: assert (a);
    end
endmodule
