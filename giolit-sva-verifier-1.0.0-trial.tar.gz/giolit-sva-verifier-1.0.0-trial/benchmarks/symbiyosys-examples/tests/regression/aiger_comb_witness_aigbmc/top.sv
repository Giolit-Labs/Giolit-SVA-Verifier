module top(input a);
    always @* assert (!a);
endmodule
