module top(input clk);
    reg [7:0] counter = 0;
    wire derived = counter * 7;

    always @(posedge clk) begin
        counter <= counter + 1;
        assert (counter < 4);
    end
endmodule
