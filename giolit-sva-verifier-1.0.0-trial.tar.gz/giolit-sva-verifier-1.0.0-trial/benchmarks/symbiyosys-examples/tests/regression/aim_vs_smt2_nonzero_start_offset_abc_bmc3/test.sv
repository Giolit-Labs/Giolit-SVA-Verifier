module test (
    input clk,
    input [8:1] nonzero_offset
);
    reg [7:0] counter = 0;

    always @(posedge clk) begin
        if (counter == 3) assert(nonzero_offset[1]);
        counter <= counter + 1;
    end
endmodule
