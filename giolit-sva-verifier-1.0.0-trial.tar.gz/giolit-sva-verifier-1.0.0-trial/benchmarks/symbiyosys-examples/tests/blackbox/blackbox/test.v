(* blackbox *)
module submod(a, b);
	input [7:0] a;
	output [7:0] b;
endmodule

module top;
	(*anyconst*) wire [7:0] a;
	wire [7:0] b;

	submod submod(
		.a(a),
		.b(b)
	);

	always @* begin
		assert(~a == b);
	end
endmodule
