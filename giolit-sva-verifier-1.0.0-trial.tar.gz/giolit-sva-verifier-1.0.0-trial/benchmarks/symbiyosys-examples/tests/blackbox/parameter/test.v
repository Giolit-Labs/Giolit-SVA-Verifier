(* blackbox *)
module submod #(parameter WIDTH = 24) (input [WIDTH-1:0] a, output [WIDTH-1:0] b);
endmodule

module top;
	(*anyconst *) wire [7:0] a;
    wire [7:0] b;

	submod #(.WIDTH(8)) submod(
		.a(a),
		.b(b)
	);

	always @* begin
		assert(~a == b);
	end
endmodule
