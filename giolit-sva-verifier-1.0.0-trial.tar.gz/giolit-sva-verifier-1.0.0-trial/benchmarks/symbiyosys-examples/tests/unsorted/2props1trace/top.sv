module top(
input foo,
input bar
);
always @(*) begin
	assert (foo);
	assert (bar);
end
endmodule
