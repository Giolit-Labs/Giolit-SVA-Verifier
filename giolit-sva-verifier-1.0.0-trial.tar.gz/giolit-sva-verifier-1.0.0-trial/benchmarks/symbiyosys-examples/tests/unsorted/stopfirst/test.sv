module test(input foo);
always @* assert(foo);
always @* assert(!foo);
endmodule
