module test(input foo);
always @* assert(foo);
always @* assert(!foo);
always @* cover(foo);
always @* cover(!foo);
endmodule

module top();
test test_i (
.foo(1'b1)
);
endmodule
