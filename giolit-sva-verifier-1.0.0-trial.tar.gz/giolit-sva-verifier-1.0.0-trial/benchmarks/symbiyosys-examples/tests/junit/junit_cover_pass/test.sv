module test(input foo);
`ifdef PREUNSAT
always @* assume(!foo);
`endif
always @* cover(foo);
`ifdef FAIL
always @* cover(!foo);
`endif
`ifdef FAIL_ASSERT
always @* assert(!foo);
`endif
endmodule

module top();
test test_i (
.foo(1'b1)
);
endmodule
