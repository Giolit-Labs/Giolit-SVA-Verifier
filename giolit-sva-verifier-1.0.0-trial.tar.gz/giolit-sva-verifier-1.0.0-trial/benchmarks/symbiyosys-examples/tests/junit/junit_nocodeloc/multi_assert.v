module test();
always @* begin
assert (1);
assert (0);
end
endmodule
