module test(input foo);
always @* assert(foo);
`ifdef FAIL
always @* assert(!foo);
`endif
`ifdef PREUNSAT
always @* assume(!foo);
`endif
endmodule

module top();
test test_i (
.foo(1'b1)
);
endmodule
